const bar = document.getElementById('bar');
const close = document.getElementById('close');
const nav = document.getElementById('nav');

if (bar) {
    bar.addEventListener('click', () => {
        nav.classList.add(`active`);

})
}

if (close) {
    close.addEventListener('click', () => {
        nav.classList.remove(`active`);
})
}
//end responsive nav bar
//loader
var loader = document.getElementById('preloader');
window.addEventListener("load", function(){
    loader.style.display = 'none';
})
// animation on scroll
// let sections = document.querySelectorAll('section');
// window.onscroll()   {
//     sections.forEach(section => {
//         let top = window.scrollY;
//         let offset = sec.offsetTop;
//         let height = sec.offsetHeight;
//         if (top >= offset && top < offset +height){
//             sec.classList.add('show-animation')
//         } else {
//             sec.classList.remove('show-animation')
//         }
// })
// }




